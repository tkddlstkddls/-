<?php

$id = $_POST['id'];
$name = $_POST['name'];
$pwd = $_POST['pwd'];
$pwd2 = $_POST['pwd2'];


if($pwd != $pwd2){
  echo "비밀번호가 일치하지 않습니다.<br>";
  echo "<a href = register.html> 회원가입 바로가기 </a>";
  exit();
}
if($id == null || $name == null || $pwd == null || $pwd2 == null){
  echo "빈칸을 모두 채워주세요.<br>";
    echo "<a href = register.html> 회원가입 바로가기 </a>";
    exit();
}

$mysqli = mysqli_connect("localhost","root","tkddls0730","final");
$select = "SELECT * FROM finalregister WHERE ID = '$id'"; //id에 따옴표로 묶어주는것 주의
$res = $mysqli->query($select);
if($res -> num_rows >= 1){
  echo "중복된 아이디 입니다.";
  exit();
}

$sql = mysqli_query($mysqli ,"INSERT into finalregister (ID , NAME , PASSWORD , created) values ('$id','$name','$pwd' , now())");

if($sql == TRUE){
  echo "회원가입 성공<br><br>";
  echo "<a href = login.html> 로그인 바로가기 </a>";
}
 ?>
