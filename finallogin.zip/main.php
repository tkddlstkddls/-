<?php
  session_start();

  if($_SESSION['ID'] != NULL){
    echo "로그인 성공!<br><br><br>";
  }
  else{
    echo "<script>location.href ='login.html';</script>";
  }

  echo "<a href = logout.php> 로그아웃 </a>";
 ?>
