<?php
  session_start();
  $userid = $_POST['id'];
  $userpwd = $_POST['pwd'];


  $mysqli = mysqli_connect("localhost" , "root" , "tkddls0730" , "final");
  $select = "SELECT * from finalregister WHERE ID = '$userid' AND PASSWORD = '$userpwd'";
  $result = $mysqli->query($select);
  $row = $result->fetch_array(MYSQLI_ASSOC);
  if($row != null){
    $_SESSION['ID'] = $userid;
    echo "<script>location.href='main.php';</script>";
  }
  else{
    echo "로그인 실패<br><br>";
    echo "<a href = login.html> 로그인 바로가기 </a>";
  }
 ?>
