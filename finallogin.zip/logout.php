<?php
session_start();
$res = session_destroy();

if($res == true){
  echo "<script>location.href ='main.php';</script>";
}

 ?>
