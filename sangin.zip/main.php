<!doctype html>
<html>
<head>
</head>
<body>
  <h1 style = "color:green ; font_size:100"> main page </h1>
  <?php

  echo "<a href = logout.php>로그아웃</a>";
  ?>
</body>
</html>
