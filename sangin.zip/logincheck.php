<?php
session_start();
$login_id = $_POST['title'];
$login_pwd = $_POST['description'];
$mysqli = mysqli_connect("localhost","root","tkddls0730","register");

$check = "SELECT * FROM register WHERE ID = '$login_id' AND PASSWORD = '$login_pwd'";
$result = $mysqli->query($check);
$row = $result->fetch_array(MYSQLI_ASSOC);
if($row !=NULL){
      $_SESSION['ID'] = $login_id;
      echo "로그인 성공!<br><br><br><br><br>\n\n\n\n\n";
      echo "<a href=main.php> 메인화면 </a>";
}
else{
  echo "로그인 실패...";
}
?>
