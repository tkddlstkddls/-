<?php
session_start();
$name=$_POST['name'];
$id=$_POST['title'];
$pwd=$_POST['description'];
$pwd2=$_POST['cdescription'];

if($pwd != $pwd2){
  echo "패스워드 확인이 일치하지 않습니다.<br>\n";
  echo "<a href =register.html>뒤로 가기</a>";
  exit();
}

if($name == NULL || $id == NULL || $pwd == NULL || $pwd2 == NULL){
  echo "빈칸을 모두 채워주세요.<br>\n";
  echo "<a href=register.html>뒤로 가기</a>";
  exit;
}


$mysqli = mysqli_connect("localhost", "root", "tkddls0730", "register");
$select = "SELECT * from register WHERE ID ='{$id}'";
$result = $mysqli->query($select); // 쿼리실행, 결과는 $result에 담김
if($result -> num_rows >= 1){ // 쿼리의 결과로 넘어온 행의 갯수를 알수 있음.
  echo "중복된 ID 입니다.<br><br><br><br><br>\n\n\n\n\n";
  echo "<a href=register.html>뒤로 가기</a>";
  exit;
}

$sql = mysqli_query($mysqli, "insert into register (NAME,ID,PASSWORD) VALUES ('$name','$id','$pwd')");

if($sql == TRUE){
  echo "회원가입 성공!<br><br><br><br>\n\n\n\n";
  echo "<a href=login.html>로그인 화면 가기</a>";
}
else {
  echo "회원가입 실패";
}
?>
